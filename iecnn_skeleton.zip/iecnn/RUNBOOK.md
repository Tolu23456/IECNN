# Runbook

Exact commands to set up, run tests, run an experiment, resume a run, and view
results. The agent keeps this file up to date.
