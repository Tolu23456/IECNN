# Decisions log

Every choice the spec did not fix. One entry per decision.

| Date | Decision | Why | Alternatives considered |
|---|---|---|---|
