# IECNN project skeleton

This folder is a starting skeleton. Most files are stubs: they contain the
function and class names, what each one must do, and which part of the spec
it comes from. The build agent fills them in, phase by phase.

Files that already work (and have passing tests): src/config.py, src/utils.py,
src/data/prepare.py (split and normalize), src/ubm/tokenizer.py (constants and
normalization), src/models/memory.py (banded mask).

Everything else raises NotImplementedError until the agent builds it.
Every test that is a stub is marked "skip" so you can see the checklist.

Start: put IECNN_FULL_SPEC.md in the spec/ folder, then give the agent
IECNN_AGENT_PROMPT.md.
