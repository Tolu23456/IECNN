Put IECNN_FULL_SPEC.md in this folder.
